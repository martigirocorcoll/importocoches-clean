class Model < ApplicationRecord
end
