class Encargo < ApplicationRecord
end
