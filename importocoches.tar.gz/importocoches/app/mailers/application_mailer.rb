class ApplicationMailer < ActionMailer::Base
  default from: 'info@importocotxe.ad'
  layout 'mailer'
end
