require_relative "boot"

require "rails/all"

# Require the gems listed in Gemfile, including any gems
# you've limited to :test, :development, or :production.
Bundler.require(*Rails.groups)

module ImportyGarageApp
  class Application < Rails::Application
    config.generators do |generate|
      generate.assets false
      generate.helper false
      generate.test_framework :test_unit, fixture: false
    end
    # Initialize configuration defaults for originally generated Rails version.
    config.load_defaults 6.1
    config.i18n.available_locales = [:en, :es, :fr, :cat, :ru, :de, :nl]
    config.i18n.default_locale = :es
    # config.middleware.use Rack::Locale
    
    # Enable Rack::Attack middleware
    config.middleware.use Rack::Attack

    # config.assets.initialize_on_precompile = true
    # config.assets.compile = true
    # Configuration for the application, engines, and railties goes here.
    #
    # These settings can be overridden in specific environments using the files
    # in config/environments, which are processed later.
    #
    config.time_zone = "Madrid"
    # config.eager_load_paths << Rails.root.join("extras")
  end
end
