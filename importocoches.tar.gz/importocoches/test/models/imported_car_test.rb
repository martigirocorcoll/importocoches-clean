require "test_helper"

class ImportedCarTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
