# Preview all emails at http://localhost:3000/rails/mailers/contacto_mailer
class ContactoMailerPreview < ActionMailer::Preview

  # Preview this email at http://localhost:3000/rails/mailers/contacto_mailer/received
  def received
    ContactoMailer.received
  end

end
